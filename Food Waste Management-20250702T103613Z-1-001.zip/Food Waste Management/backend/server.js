const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Initialize Express app
const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads')); // Serve static images

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/foodwaste', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Define FoodLog Schema
const foodSchema = new mongoose.Schema({
  hotelName: { type: String, required: true },
  foodType: { type: String, required: true },
  quantity: { type: Number, required: true },
  pickupAddress: { type: String, required: true },
  expirationTime: { type: Date, required: true },
  contactNumber: { type: String, required: true },
  imageUrl: { type: String },
});

// Define ExpiredFood Schema (for expired items)
const expiredFoodSchema = new mongoose.Schema({
  hotelName: { type: String, required: true },
  foodType: { type: String, required: true },
  quantity: { type: Number, required: true },
  pickupAddress: { type: String, required: true },
  expirationTime: { type: Date, required: true },
  contactNumber: { type: String, required: true },
  imageUrl: { type: String },
  expiredAt: { type: Date, default: Date.now },
});

// Define ReadFood Schema (for read expired items)
const readFoodSchema = new mongoose.Schema({
  hotelName: { type: String, required: true },
  foodType: { type: String, required: true },
  quantity: { type: Number, required: true },
  pickupAddress: { type: String, required: true },
  expirationTime: { type: Date, required: true },
  contactNumber: { type: String, required: true },
  imageUrl: { type: String },
  readAt: { type: Date, default: Date.now },
});

// Create Models
const FoodLog = mongoose.model('FoodLog', foodSchema);
const ExpiredFood = mongoose.model('ExpiredFood', expiredFoodSchema);
const ReadFood = mongoose.model('ReadFood', readFoodSchema);

// Configure multer for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = 'uploads';
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath); // Ensure directory exists
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}${path.extname(file.originalname)}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // Limit file size to 5MB
  fileFilter: (req, file, cb) => {
    const fileTypes = /jpeg|jpg|png/;
    const extName = fileTypes.test(path.extname(file.originalname).toLowerCase());
    const mimeType = fileTypes.test(file.mimetype);
    if (extName && mimeType) {
      return cb(null, true);
    } else {
      cb(new Error('Only images (jpg, jpeg, png) are allowed.'));
    }
  },
});

// Routes
// ✅ GET route to fetch all food logs and move expired items
app.get('/food', async (req, res) => {
  try {
    const now = new Date();

    // Find and move expired food logs to the ExpiredFood collection
    const expiredItems = await FoodLog.find({ expirationTime: { $lt: now } });
    if (expiredItems.length > 0) {
      await ExpiredFood.insertMany(expiredItems.map(item => ({ ...item.toObject() })));
      await FoodLog.deleteMany({ expirationTime: { $lt: now } });
    }

    // Fetch remaining food logs
    const foodLogs = await FoodLog.find();
    res.json(foodLogs);
  } catch (error) {
    res.status(500).json({ message: '❌ Failed to fetch food logs.', error: error.message });
  }
});

// ✅ POST route to add a food log with image upload
app.post('/food', upload.single('foodImage'), async (req, res) => {
  try {
    const { hotelName, foodType, quantity, pickupAddress, expirationTime, contactNumber } = req.body;

    // Check if an image file is uploaded
    if (!req.file) {
      return res.status(400).json({ message: '❌ Image is required.' });
    }

    // Create a new food log entry
    const foodLog = new FoodLog({
      hotelName,
      foodType,
      quantity,
      pickupAddress,
      expirationTime,
      contactNumber,
      imageUrl: `/uploads/${req.file.filename}`, // Correctly store image URL
    });

    // Save the food log to the correct collection
    const savedFoodLog = await foodLog.save(); // Ensure it saves to `FoodLog`

    // Send success response
    res.json({ message: '✅ Food log added successfully!', data: savedFoodLog });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: '❌ Failed to add food log.', error: error.message });
  }
});

// ✅ DELETE route to remove a food log by ID
app.delete('/food/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const deletedLog = await FoodLog.findByIdAndDelete(id);

    if (!deletedLog) {
      return res.status(404).json({ message: '❌ Food log not found.' });
    }

    // Delete the associated image file
    if (deletedLog.imageUrl) {
      const imagePath = path.join(__dirname, deletedLog.imageUrl);
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
      }
    }

    res.json({ message: '✅ Food log deleted successfully!' });
  } catch (error) {
    res.status(500).json({ message: '❌ Failed to delete food log.', error: error.message });
  }
});

// ✅ GET route to fetch all expired food logs
app.get('/expired-food', async (req, res) => {
  try {
    const expiredFoodLogs = await ExpiredFood.find();
    res.json(expiredFoodLogs);
  } catch (error) {
    res.status(500).json({ message: '❌ Failed to fetch expired food logs.', error: error.message });
  }
});

// ✅ POST route to mark an expired food log as read
app.post('/expired-food/mark-as-read', async (req, res) => {
  try {
    const { _id } = req.body;

    const expiredFood = await ExpiredFood.findById(_id);
    if (!expiredFood) {
      return res.status(404).json({ message: '❌ Food log not found.' });
    }

    const readFood = new ReadFood(expiredFood.toObject());
    await readFood.save();
    await ExpiredFood.findByIdAndDelete(_id);

    res.json({ message: '✅ Food log marked as read and moved to the ReadFood collection.' });
  } catch (error) {
    res.status(500).json({ message: '❌ Failed to mark food log as read.', error: error.message });
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
